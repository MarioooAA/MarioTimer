const path = require('path');

module.exports = {
  mode: 'development',
  entry: './src/index.js',
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, 'dist'),
  },
  module: {
    rules: [
      {
        test: /.scss$/, // Procesar archivos SCSS
        use: ['style-loader', 'css-loader', 'sass-loader'], // Cargar y compilar SCSS
      },
      {
        test: /.js$/, // Procesar archivos JavaScript
        exclude: /node_modules/,
        use: 'babel-loader', // Usar Babel para transpilar JS
      },
    ],
  },
  resolve: {
    extensions: ['.js', '.jsx', '.json'], // Resolución de extensiones
  },
};
